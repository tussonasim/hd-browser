package com.example.hdbrowser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Entry(val title: String, val url: String)

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("hdbrowser", Context.MODE_PRIVATE)

    var dark: Boolean
        get() = sp.getBoolean("dark", false)
        set(v) = sp.edit().putBoolean("dark", v).apply()

    fun bookmarks(): MutableList<Entry> = read("bookmarks")
    fun history(): MutableList<Entry> = read("history")

    fun saveBookmarks(list: List<Entry>) = write("bookmarks", list)
    fun saveHistory(list: List<Entry>) = write("history", list)

    /** @return true if added, false if it already existed */
    fun addBookmark(e: Entry): Boolean {
        val list = bookmarks()
        if (list.any { it.url == e.url }) return false
        list.add(0, e)
        saveBookmarks(list)
        return true
    }

    fun isBookmarked(url: String?) = url != null && bookmarks().any { it.url == url }

    fun addHistory(e: Entry) {
        val list = history()
        list.removeAll { it.url == e.url }
        list.add(0, e)
        saveHistory(list.take(200))
    }

    private fun read(key: String): MutableList<Entry> {
        val out = mutableListOf<Entry>()
        try {
            val arr = JSONArray(sp.getString(key, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Entry(o.optString("t"), o.optString("u")))
            }
        } catch (_: Exception) { }
        return out
    }

    private fun write(key: String, list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("t", it.title).put("u", it.url)) }
        sp.edit().putString(key, arr.toString()).apply()
    }
}
