package com.example.hdbrowser

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.text.TextUtils
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature

class MainActivity : AppCompatActivity() {

    private class BrowserTab(val web: WebView, val label: TextView) {
        var desktop = false
    }

    private val homeUrl = "https://www.google.com"
    private val desktopUA =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/120.0.0.0 Safari/537.36"

    private lateinit var store: Store
    private lateinit var root: View
    private lateinit var tabBar: View
    private lateinit var toolbar: View
    private lateinit var urlBar: EditText
    private lateinit var btnStar: Button
    private lateinit var progress: ProgressBar
    private lateinit var webContainer: FrameLayout
    private lateinit var tabContainer: LinearLayout
    private val tabs = mutableListOf<BrowserTab>()
    private var current: BrowserTab? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        AppCompatDelegate.setDefaultNightMode(
            if (store.dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        tabBar = findViewById(R.id.tabBar)
        toolbar = findViewById(R.id.toolbar)
        urlBar = findViewById(R.id.urlBar)
        btnStar = findViewById(R.id.btnStar)
        progress = findViewById(R.id.progress)
        webContainer = findViewById(R.id.webContainer)
        tabContainer = findViewById(R.id.tabContainer)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        findViewById<Button>(R.id.btnBack).setOnClickListener {
            current?.web?.let { if (it.canGoBack()) it.goBack() }
        }
        findViewById<Button>(R.id.btnForward).setOnClickListener {
            current?.web?.let { if (it.canGoForward()) it.goForward() }
        }
        findViewById<Button>(R.id.btnReload).setOnClickListener { current?.web?.reload() }
        findViewById<Button>(R.id.btnHome).setOnClickListener { current?.web?.loadUrl(homeUrl) }
        findViewById<Button>(R.id.btnNewTab).setOnClickListener { openTab(homeUrl) }
        btnStar.setOnClickListener { addBookmark() }
        findViewById<Button>(R.id.btnMenu).setOnClickListener { showMenu(it) }

        urlBar.setOnEditorActionListener { _, actionId, event ->
            val enter = event?.keyCode == KeyEvent.KEYCODE_ENTER &&
                event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                current?.web?.loadUrl(toUrl(urlBar.text.toString()))
                hideKeyboard()
                true
            } else false
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val tab = current
                when {
                    tab != null && tab.web.canGoBack() -> tab.web.goBack()
                    tab != null && tabs.size > 1 -> closeTab(tab)
                    else -> finish()
                }
            }
        })

        openTab(homeUrl)
        applyTheme()
    }

    // ---------------------------------------------------------------- tabs

    @SuppressLint("SetJavaScriptEnabled")
    private fun openTab(url: String) {
        val web = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                useWideViewPort = true
                loadWithOverviewMode = true
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
            }
        }
        applyWebDark(web)

        val label = TextView(this).apply {
            text = "New Tab"
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(dp(170), ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        val tab = BrowserTab(web, label)
        label.setOnClickListener { select(tab) }
        label.setOnLongClickListener { closeTab(tab); true }

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (tab === current) {
                    urlBar.setText(url)
                    updateStar()
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (url == null || url == "about:blank") return
                store.addHistory(Entry(view?.title?.ifBlank { url } ?: url, url))
                if (tab === current) {
                    urlBar.setText(url)
                    updateStar()
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (tab === current) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
                }
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                if (!title.isNullOrBlank()) label.text = title
            }
        }
        web.setDownloadListener { dlUrl, userAgent, contentDisposition, mimeType, _ ->
            startDownload(dlUrl, userAgent, contentDisposition, mimeType)
        }

        tabs.add(tab)
        webContainer.addView(web)
        tabContainer.addView(label)
        select(tab)
        web.loadUrl(url)
    }

    private fun select(tab: BrowserTab) {
        current = tab
        for (t in tabs) t.web.visibility = if (t === tab) View.VISIBLE else View.GONE
        urlBar.setText(tab.web.url ?: "")
        progress.visibility = View.GONE
        styleTabs()
        updateStar()
    }

    private fun closeTab(tab: BrowserTab) {
        if (tabs.size == 1) {
            tab.web.loadUrl(homeUrl)
            return
        }
        val index = tabs.indexOf(tab)
        tabs.remove(tab)
        webContainer.removeView(tab.web)
        tabContainer.removeView(tab.label)
        tab.web.destroy()
        select(tabs[minOf(index, tabs.size - 1)])
    }

    // ----------------------------------------------------------- menu & lists

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Add bookmark")
        pm.menu.add(0, 2, 1, "Bookmarks")
        pm.menu.add(0, 3, 2, "History")
        pm.menu.add(0, 4, 3, "Downloads")
        pm.menu.add(0, 5, 4, "Desktop site").apply {
            isCheckable = true
            isChecked = current?.desktop == true
        }
        pm.menu.add(0, 6, 5, "Dark mode").apply {
            isCheckable = true
            isChecked = store.dark
        }
        pm.menu.add(0, 7, 6, "Clear history")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> addBookmark()
                2 -> showList("Bookmarks", store.bookmarks()) { list -> store.saveBookmarks(list) }
                3 -> showList("History", store.history()) { list -> store.saveHistory(list) }
                4 -> startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
                5 -> toggleDesktop()
                6 -> toggleDark()
                7 -> { store.saveHistory(emptyList()); toast("History cleared") }
            }
            true
        }
        pm.show()
    }

    private fun addBookmark() {
        val web = current?.web ?: return
        val url = web.url ?: return
        val added = store.addBookmark(Entry(web.title?.ifBlank { url } ?: url, url))
        toast(if (added) "Bookmark added" else "Already bookmarked")
        updateStar()
    }

    private fun updateStar() {
        btnStar.text = if (store.isBookmarked(current?.web?.url)) "★" else "☆"
    }

    private fun showList(title: String, items: MutableList<Entry>, save: (List<Entry>) -> Unit) {
        if (items.isEmpty()) {
            toast("$title is empty")
            return
        }
        val labels = items.map { it.title.ifBlank { it.url } }.toMutableList()
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        val dialog = AlertDialog.Builder(this)
            .setTitle("$title (long-press = delete)")
            .setAdapter(adapter, null)
            .setNegativeButton("Close", null)
            .create()
        dialog.show()
        dialog.listView.setOnItemClickListener { _, _, i, _ ->
            current?.web?.loadUrl(items[i].url)
            dialog.dismiss()
        }
        dialog.listView.setOnItemLongClickListener { _, _, i, _ ->
            items.removeAt(i)
            labels.removeAt(i)
            adapter.notifyDataSetChanged()
            save(items)
            updateStar()
            true
        }
    }

    // -------------------------------------------------------------- download

    private fun startDownload(url: String, userAgent: String?, disposition: String?, mime: String?) {
        try {
            val name = URLUtil.guessFileName(url, disposition, mime)
            val req = DownloadManager.Request(Uri.parse(url)).apply {
                setMimeType(mime)
                setTitle(name)
                userAgent?.let { addRequestHeader("User-Agent", it) }
                CookieManager.getInstance().getCookie(url)?.let { addRequestHeader("Cookie", it) }
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            }
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast("Downloading: $name")
        } catch (e: Exception) {
            toast("Download failed")
        }
    }

    // ------------------------------------------------------------- dark mode

    private fun toggleDark() {
        store.dark = !store.dark
        AppCompatDelegate.setDefaultNightMode(
            if (store.dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        applyTheme()
    }

    private fun applyTheme() {
        val dark = store.dark
        root.setBackgroundColor(if (dark) 0xFF121212.toInt() else Color.WHITE)
        val bar = if (dark) 0xFF1F1F1F.toInt() else 0xFFECEFF1.toInt()
        tabBar.setBackgroundColor(bar)
        toolbar.setBackgroundColor(bar)
        urlBar.setTextColor(if (dark) Color.WHITE else Color.BLACK)
        urlBar.setHintTextColor(Color.GRAY)
        styleTabs()
        tabs.forEach { applyWebDark(it.web) }
    }

    private fun styleTabs() {
        val dark = store.dark
        val bg = if (dark) 0xFF121212.toInt() else Color.WHITE
        val fg = if (dark) Color.WHITE else Color.BLACK
        for (t in tabs) {
            t.label.setTextColor(fg)
            t.label.setBackgroundColor(if (t === current) bg else Color.TRANSPARENT)
        }
    }

    private fun applyWebDark(web: WebView) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(web.settings, store.dark)
        }
    }

    // ----------------------------------------------------------------- misc

    private fun toggleDesktop() {
        val tab = current ?: return
        tab.desktop = !tab.desktop
        tab.web.settings.userAgentString = if (tab.desktop) desktopUA else null
        tab.web.reload()
    }

    private fun toUrl(input: String): String {
        val t = input.trim()
        return when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(" ") || !t.contains(".") ->
                "https://www.google.com/search?q=" + Uri.encode(t)
            else -> "https://$t"
        }
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(urlBar.windowToken, 0)
        urlBar.clearFocus()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onPause() { super.onPause(); tabs.forEach { it.web.onPause() } }
    override fun onResume() { super.onResume(); tabs.forEach { it.web.onResume() } }
    override fun onDestroy() { tabs.forEach { it.web.destroy() }; super.onDestroy() }
}
